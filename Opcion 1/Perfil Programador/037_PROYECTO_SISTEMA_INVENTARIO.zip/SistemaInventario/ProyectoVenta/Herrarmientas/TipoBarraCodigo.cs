﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BarcodeLib;

namespace ProyectoVenta.Herrarmientas
{
    public class TipoBarraCodigo
    {
        public static TYPE TipoCodigo = TYPE.CODE128;
    }
}
