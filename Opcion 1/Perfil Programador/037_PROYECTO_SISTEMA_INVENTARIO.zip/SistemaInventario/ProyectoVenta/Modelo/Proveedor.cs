﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoVenta.Modelo
{
    public class Proveedor
    {
        public int IdProveedor { get; set; }
        public string NumeroDocumento { get; set; }
        public string NombreCompleto { get; set; }
    }
}
